 <main>
        
        <section class="well ins1">
          <div class="container hr">
            Hugo Carwash adalah 
            <br>
            <ul class="row product-list">
              <li class="grid_6">
                <div class="box wow fadeInRight">
                  <div class="box_aside">
                    <div class="icon fa-clipboard">1</div>
                  </div>
                  <div class="box_cnt__no-flow">
                    <h3><a href="#">Dijamin Bersih</a></h3>
                    <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolor.</p>
                  </div>
                </div>
                <hr>
                <div data-wow-delay="0.2s" class="box wow fadeInRight">
                  <div class="box_aside">
                    <div class="icon fa-clipboard">2</div>
                  </div>
                  <div class="box_cnt__no-flow">
                    <h3><a href="#">Dijamin Wangi</a></h3>
                    <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolor.</p>
                  </div>
                </div>
              </li>
              <li class="grid_6">
                <div data-wow-delay="0.3s" class="box wow fadeInRight">
                  <div class="box_aside">
                    <div class="icon fa-group">3</div>
                  </div>
                  <div class="box_cnt__no-flow">
                    <h3><a href="#">Dijamin Kilat</a></h3>
                    <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolor.</p>
                  </div>
                </div>
                <hr>
                <div data-wow-delay="0.4s" class="box wow fadeInRight">
                  <div class="box_aside">
                    <div class="icon fa-thumbs-up">4</div>
                  </div>
                  <div class="box_cnt__no-flow">
                    <h3><a href="#">Dijamin Puas</a></h3>
                    <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolor.</p>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </section>
        
      </main>