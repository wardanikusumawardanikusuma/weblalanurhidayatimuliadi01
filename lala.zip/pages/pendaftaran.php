 <main>
        
        <section class="well1">
          <div class="container">
            <h2>Pendaftaran</h2>
            <form method="post" action="bat/rd-mailform.php" class="mailform off2">
              <input type="hidden" name="form-type" value="contact">
              <fieldset class="row">
                <label class="grid_4">
                  <input type="text" name="nama" placeholder="Nama">
                </label>
                <label class="grid_4">
                  <input type="text" name="telp" placeholder="No. Handphone">
                </label>
                <label class="grid_4">
                  <input type="text" name="alamat" placeholder="Alamat">
                </label>
                <br><br><br>
                <label class="grid_4">
                  <input type="text" name="nomor_plat" placeholder="Nomor Plat">
                </label>
                <label class="grid_4">
                  <select>
                    <option>Honda</option>
                    <option>Toyota</option>
                    <option>Toyota</option>
                  </select>
                </label>
                <br>
                <div class="mfControls grid_12">
                  <button type="submit" class="btn">Kirim</button>
                </div>
              </fieldset>
            </form>
          </div>
        </section>
      </main>